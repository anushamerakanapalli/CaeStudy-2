package com.main.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.main.model.Order;



@FeignClient(name="order-service")
public interface OrderFeign {

	 @GetMapping("/order/order/{orderId}")
	    public ResponseEntity<Order> buyUsingId(@PathVariable("orderId") int orderId);
	    
	    @GetMapping("/order/getTotalAmount/{orderId}")
	    public double getTotalAmount(@PathVariable("orderId") int orderId);

		public float getTotalamount(int order_id);
	
}
