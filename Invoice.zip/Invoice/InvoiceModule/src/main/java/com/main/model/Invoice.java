package com.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="invoice")
public class Invoice {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int invoice_id;
	private int order_id;
	private float totalamount;
	private String payment_status;
	
	public int getInvoice_id() {
		return invoice_id;
	}

	public void setInvoice_id(int invoice_id) {
		this.invoice_id = invoice_id;
	}

	public int getOrder_id() {
		return order_id;
	}

	public void setO_id(int order_id) {
		this.order_id = order_id;
	}

	public float getTotalamount() {
		return totalamount;
	}

	public void setTotalamount(float totalamount) {
		this.totalamount = totalamount;
	}

	public String getPayment_status() {
		return payment_status;
	}

	public void setPayment_status(String payment_status) {
		this.payment_status = payment_status;
	}

	public Invoice(int in_id, int order_id, float totalamount, String payment_status) {
		super();
		this.invoice_id = invoice_id;
		this.order_id = order_id;
		this.totalamount = totalamount;
		this.payment_status = payment_status;
	}
	public String toString() {
		return "Invoice [in_id=" + invoice_id + ", order_id=" + order_id + ", totalamount=" + totalamount + ", payment_status="
				+ payment_status + "]";
	}

	public Invoice() {}
	
}
