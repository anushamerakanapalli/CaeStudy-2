package com.main.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.main.dao.InvoiceRepository;
import com.main.model.Invoice;
@Service
@Transactional

public class InvoiceServiceImpl implements InvoiceServiceIntf {
	
	@Autowired
	InvoiceRepository  invRepo;
	
	public void saveInvoice(Invoice invo,float totalamount) {
		
		invo.setTotalamount(totalamount);
		invRepo.save(invo);	
	}
	
	public List<Invoice> fetchDetails() {
		
		return invRepo.findAll();
	}

	
	public Optional<Invoice> getInvoiceById(int invoice_id) {
		
		return invRepo.findById(invoice_id);
	}

	
	public void deleteById(int id) {
		
		invRepo.deleteById(id);
		
	}
	
	/*public void invoiceCalculate(float productPrice, int quantity  ) {
		
		
		
	}*/

	

	

}
