package com.main.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.main.model.Product;

@FeignClient(name="product-service")
public interface ProductFeign {

	@GetMapping("product/getProduct/{productId}")
    public ResponseEntity<Product> buyUsingId(@PathVariable("productId") int productId); 

	
}
