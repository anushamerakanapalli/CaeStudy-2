package com.main.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.main.model.Product;
import com.main.service.ProductServiceIntf;

@RestController
@RequestMapping("/product")
public class ProductController {

	@Autowired
	private ProductServiceIntf prodServ;

	@PostMapping("/saveProduct")
	public ResponseEntity<String> saveProduct(@RequestBody Product product) {
		//String msg="";
	
		prodServ.saveProductDetails(product);
		return new ResponseEntity<String>("Product Added", HttpStatus.CREATED);
	}
	
	@GetMapping("/getProduct")
    public ResponseEntity<List<Product>> fetchData() {
        List<Product> list = prodServ.fetchData();
        if (list.size() == 0) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(list, HttpStatus.OK);
    }
	
	
	@GetMapping("/product/{productId}")
    public ResponseEntity<Optional<Product>> buyUsingId(@PathVariable("productId") int productId) {
		Optional<Product> option = prodServ.buyUsingId(productId);
        if (option.isPresent()) 
            return new ResponseEntity<>(option, HttpStatus.OK);
        else
        	return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@DeleteMapping("/product/{id}")
    void deleteProduct(@PathVariable int id) {
		prodServ.deleteById(id);
		
	//String val="Value deleted ith Product ID"+ product.getId();
	
	}
	
}
